# AISZ GAME SPACE v1.2.0

Aplikasi Android (Kotlin + Jetpack Compose): dashboard bertema hitam-biru, panel gaming melayang,
game launcher dengan profil per game, monitor FPS/suhu/WLAN/latensi/RAM, rekam layar, Jangan Ganggu,
dan dukungan Shizuku (dimulai lewat ADB nirkabel).

- Package: `com.aisz.gamespace` - minSdk 24, target/compileSdk 35
- AGP 8.6.1, Gradle 8.7, Kotlin 1.9.24, Compose BOM 2024.06.00, JDK 17

## Build
- GitHub Actions: `.github/workflows` (APK debug sebagai artifact), atau
- Android Studio: Build > Build APK(s), atau `gradle assembleDebug`.

## Shizuku / ADB nirkabel
Fitur sistem (FPS game, Game Mode, Penghemat Baterai, kunci refresh rate, jendela mengambang)
memakai Shizuku. Mulai Shizuku lewat Debugging nirkabel (Android 11+) atau ADB dari PC, lalu
ketuk "Izinkan" di AISZ > Atur. Tanpa Shizuku fitur tersebut dinonaktifkan dengan pesan jelas.

## Catatan jujur
- Mode Hemat/Seimbang/Performa memakai Game Mode & Penghemat Baterai bawaan Android. Efeknya bergantung
  pada game dan ROM; tidak ada jaminan kenaikan FPS.
- FPS game dibaca dari SurfaceFlinger (best effort); bila tidak terbaca tampil N/A.
- Jendela mengambang memakai `am start --windowingMode 5`; hanya jalan jika ROM mendukung freeform.
- Rekam layar tanpa audio, disimpan di Movies/AISZ.
