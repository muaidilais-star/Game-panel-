package com.aisz.gamespace.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aisz.gamespace.MainActivity

/** Urutan tab = urutan di bilah navigasi. */
enum class Tab(val label: String, val icon: ImageVector) {
    GAMES("Game", Icons.Filled.PlayArrow),
    DASHBOARD("Home", Icons.Filled.Home),
    MONITOR("Monitor", Icons.Filled.Info),
    SETTINGS("Atur", Icons.Filled.Settings)
}

/** Latar statis (digambar sekali, tanpa animasi terus-menerus agar HP tidak berat). */
@Composable
private fun AmbientGlow() {
    Canvas(Modifier.fillMaxSize()) {
        val r = size.maxDimension * 0.55f
        val c1 = Offset(size.width * 0.15f, size.height * 0.06f)
        val c2 = Offset(size.width * 0.9f, size.height * 0.95f)
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.Neon.copy(alpha = 0.16f), Color.Transparent), center = c1, radius = r),
            radius = r, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(AiszColors.NeonSoft.copy(alpha = 0.10f), Color.Transparent), center = c2, radius = r),
            radius = r, center = c2
        )
    }
}

@Composable
private fun PillNav(tab: Tab, onSelect: (Tab) -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Box(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier
                .clip(shape)
                .background(AiszColors.Surface.copy(alpha = 0.96f))
                .border(1.dp, AiszColors.Neon.copy(alpha = 0.3f), shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tab.values().forEach { t ->
                val sel = tab == t
                Row(
                    Modifier
                        .clip(RoundedCornerShape(26.dp))
                        .background(if (sel) AiszColors.Neon.copy(alpha = 0.2f) else Color.Transparent)
                        .clickable { onSelect(t) }
                        .animateContentSize(tween(180))
                        .padding(horizontal = if (sel) 16.dp else 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(t.icon, contentDescription = t.label, tint = if (sel) AiszColors.Neon else AiszColors.TextDim)
                    if (sel) {
                        Spacer(Modifier.width(8.dp))
                        Text(t.label, color = AiszColors.Neon, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AiszApp(activity: MainActivity) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }

    Box(Modifier.fillMaxSize().background(AiszColors.Black)) {
        AmbientGlow()
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { PillNav(tab) { tab = it } }
        ) { padding ->
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.padding(padding),
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                label = "tab"
            ) { current ->
                when (current) {
                    Tab.DASHBOARD -> HomeScreen(activity) { tab = it }
                    Tab.GAMES -> GamesScreen(activity)
                    Tab.MONITOR -> MonitorScreen()
                    Tab.SETTINGS -> SettingsScreen(activity)
                }
            }
        }
    }
}
