package com.aisz.gamespace.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun GlowCard(
    modifier: Modifier = Modifier,
    contentPadding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(14.dp, shape, ambientColor = AiszColors.Neon, spotColor = AiszColors.Neon)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(AiszColors.SurfaceHigh.copy(alpha = 0.95f), AiszColors.Surface.copy(alpha = 0.95f))
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(AiszColors.Neon.copy(alpha = 0.75f), AiszColors.Neon.copy(alpha = 0.15f))),
                shape
            )
            .padding(contentPadding),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        color = AiszColors.Neon,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
fun StatRow(label: String, value: String, valueColor: Color = AiszColors.Text) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AiszColors.TextDim, fontSize = 13.sp)
        Text(
            value,
            color = valueColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = AiszColors.Neon,
            contentColor = AiszColors.Black,
            disabledContainerColor = AiszColors.SurfaceHigh,
            disabledContentColor = AiszColors.TextDim
        )
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(42.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AiszColors.Neon.copy(alpha = 0.7f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = AiszColors.Neon)
    ) { Text(text, fontSize = 13.sp) }
}

@Composable
fun NeonChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text,
        modifier = modifier
            .clip(shape)
            .background(if (selected) AiszColors.Neon.copy(alpha = 0.22f) else AiszColors.SurfaceHigh)
            .border(1.dp, if (selected) AiszColors.Neon else AiszColors.Neon.copy(alpha = 0.25f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        color = if (selected) AiszColors.Neon else AiszColors.TextDim,
        fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
    )
}

/** Muncul bertahap: fade + geser dari bawah, tertunda sesuai urutan. */
@Composable
fun Appear(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        shown = true
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 6 }
    ) { content() }
}

/** Indikator melingkar beranimasi. progress 0..1. */
@Composable
fun RingGauge(
    progress: Float,
    centerText: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    diameter: Dp = 92.dp
) {
    val anim by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(800),
        label = "gauge"
    )
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 9.dp.toPx()
                val topLeft = Offset(stroke, stroke)
                val arcSize = Size(size.width - stroke * 2, size.height - stroke * 2)
                drawArc(
                    AiszColors.SurfaceHigh, 135f, 270f, false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
                if (anim > 0.001f) {
                    drawArc(
                        color.copy(alpha = 0.25f), 135f, 270f * anim, false, topLeft, arcSize,
                        style = Stroke(stroke * 1.8f, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color, 135f, 270f * anim, false, topLeft, arcSize,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            }
            Text(centerText, color = AiszColors.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Text(label, color = AiszColors.TextDim, fontSize = 12.sp)
    }
}

/** Grafik garis riwayat. Nilai dipetakan dari [minV, maxV] ke tinggi kanvas. */
@Composable
fun Sparkline(
    values: List<Float>,
    color: Color,
    modifier: Modifier = Modifier,
    minV: Float = 0f,
    maxV: Float = 1f
) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val range = (maxV - minV).coerceAtLeast(0.0001f)
        val stepX = size.width / (values.size - 1)
        val line = Path()
        val fill = Path()
        values.forEachIndexed { i, v ->
            val x = i * stepX
            val y = size.height - ((v - minV) / range).coerceIn(0f, 1f) * size.height
            if (i == 0) {
                line.moveTo(x, y)
                fill.moveTo(x, size.height)
                fill.lineTo(x, y)
            } else {
                line.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(size.width, size.height)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Garis tipis berpendar (statis, tanpa animasi agar hemat tenaga). */
@Composable
fun ScanLine(modifier: Modifier = Modifier) {
    Canvas(modifier.height(2.dp)) {
        drawRect(
            Brush.horizontalGradient(listOf(Color.Transparent, AiszColors.Neon, Color.Transparent))
        )
    }
}

fun Context.safeStart(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(this, "Fitur ini tidak didukung di perangkat Anda.", Toast.LENGTH_SHORT).show()
    }
}
