package com.aisz.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.view.Display

data class MemoryStatus(val totalMb: Long, val availMb: Long) {
    val usedMb: Long get() = totalMb - availMb
    val usedPercent: Int get() = if (totalMb > 0) ((usedMb * 100) / totalMb).toInt() else 0
}

data class BatteryStatus(
    val levelPercent: Int?,
    val charging: Boolean,
    val temperatureC: Float?,
    val voltageMv: Int?
)

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val apiLevel: Int,
    val abi: String,
    val cpuCores: Int,
    val screen: String,
    val refreshRateHz: Float
)

/** Hanya membaca data yang disediakan Android secara resmi. */
class PerformanceMonitor(private val context: Context) {

    fun memory(): MemoryStatus {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return MemoryStatus(info.totalMem / MB, info.availMem / MB)
    }

    fun battery(): BatteryStatus {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (i == null) return BatteryStatus(null, false, null, null)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        return BatteryStatus(
            levelPercent = if (level >= 0 && scale > 0) level * 100 / scale else null,
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL,
            temperatureC = if (temp != Int.MIN_VALUE) temp / 10f else null,
            voltageMv = if (volt > 0) volt else null
        )
    }

    fun deviceInfo(): DeviceInfo {
        val dm = context.resources.displayMetrics
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val refresh = displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 0f
        return DeviceInfo(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "N/A",
            cpuCores = Runtime.getRuntime().availableProcessors(),
            screen = "${dm.widthPixels} x ${dm.heightPixels} px",
            refreshRateHz = refresh
        )
    }

    private companion object {
        const val MB = 1024L * 1024L
    }
}
