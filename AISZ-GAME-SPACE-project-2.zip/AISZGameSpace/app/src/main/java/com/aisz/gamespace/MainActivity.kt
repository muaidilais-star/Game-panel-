package com.aisz.gamespace

import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import com.aisz.gamespace.ui.AiszApp
import com.aisz.gamespace.ui.AiszTheme
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    /** Dinaikkan setiap onResume agar layar membaca ulang status izin. */
    val resumeTick = mutableStateOf(0)

    private lateinit var settings: GameSettings

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        resumeTick.value = resumeTick.value + 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        settings = GameSettings(this)
        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (_: Throwable) {
        }
        applyWindowPrefs()
        setContent {
            AiszTheme {
                AiszApp(this@MainActivity)
            }
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        resumeTick.value = resumeTick.value + 1
    }

    /** Menerapkan orientasi dan "layar tetap menyala" untuk jendela aplikasi ini. */
    fun applyWindowPrefs() {
        requestedOrientation = settings.orientation.androidValue
        if (settings.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
