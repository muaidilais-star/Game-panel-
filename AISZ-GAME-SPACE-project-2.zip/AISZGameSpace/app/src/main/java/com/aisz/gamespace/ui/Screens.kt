package com.aisz.gamespace.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aisz.gamespace.FloatingPanelService
import com.aisz.gamespace.FpsMonitor
import com.aisz.gamespace.GameInfo
import com.aisz.gamespace.GameLauncher
import com.aisz.gamespace.GameSettings
import com.aisz.gamespace.GamingProfile
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.ModeController
import com.aisz.gamespace.NetworkMonitor
import com.aisz.gamespace.OrientationMode
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.ShellTools
import com.aisz.gamespace.ShizukuHelper
import com.aisz.gamespace.TempLevel
import com.aisz.gamespace.TemperatureMonitor
import com.aisz.gamespace.formatCelsius
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

internal fun levelColor(level: TempLevel): Color = when (level) {
    TempLevel.NORMAL -> AiszColors.Ok
    TempLevel.WARM -> AiszColors.Warn
    TempLevel.HIGH -> AiszColors.Hot
    TempLevel.UNKNOWN -> AiszColors.TextDim
}

internal fun relativeTime(ts: Long): String {
    if (ts <= 0L) return "Belum pernah dibuka"
    val min = (System.currentTimeMillis() - ts) / 60000
    return when {
        min < 1 -> "Baru saja"
        min < 60 -> "$min menit lalu"
        min < 1440 -> "${min / 60} jam lalu"
        else -> "${min / 1440} hari lalu"
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String? = null) {
    Text(title, color = AiszColors.Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    if (subtitle != null) Text(subtitle, color = AiszColors.TextDim, fontSize = 13.sp)
}

// =============================================================== GAMES

@Composable
private fun GameCard(g: GameInfo, onFav: () -> Unit, onDelete: () -> Unit, onProfile: () -> Unit, onPlay: () -> Unit) {
    GlowCard(contentPadding = 10.dp) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = onFav, modifier = Modifier.size(34.dp)) {
                Icon(
                    if (g.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorit",
                    tint = if (g.isFavorite) AiszColors.Hot else AiszColors.TextDim
                )
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.Delete, contentDescription = "Hapus dari daftar", tint = AiszColors.TextDim)
            }
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            val icon = g.icon
            if (icon != null) {
                Image(
                    bitmap = icon, contentDescription = g.label,
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp))
                )
            } else {
                Box(Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(AiszColors.SurfaceHigh))
            }
            Spacer(Modifier.height(8.dp))
            Text(
                g.label, color = AiszColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(relativeTime(g.lastLaunch), color = AiszColors.TextDim, fontSize = 11.sp)
            Text("Dibuka ${g.launches}x dari AISZ", color = AiszColors.TextDim, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            NeonChip(g.profile?.label ?: "Tanpa profil", g.profile != null, onClick = onProfile)
            Spacer(Modifier.height(8.dp))
            NeonButton("MAIN", Modifier.fillMaxWidth(), onClick = onPlay)
        }
    }
}

@Composable
fun GamesScreen(activity: MainActivity) {
    val ctx = LocalContext.current
    val launcher = remember { GameLauncher(ctx) }
    val scope = rememberCoroutineScope()
    var games by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addable by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    val tick = activity.resumeTick.value

    LaunchedEffect(reload, tick) {
        loading = true
        games = withContext(Dispatchers.IO) { launcher.loadGames() }
        loading = false
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenTitle("Game Launcher", "${games.size} game di daftar") }
            NeonButton("+ Tambah") {
                scope.launch {
                    addable = withContext(Dispatchers.IO) { launcher.loadAddableApps() }
                    showAdd = true
                }
            }
        }
        Text(
            "Ketuk chip profil untuk memilih mode per game. Profil diterapkan otomatis saat game dibuka dari AISZ.",
            color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AiszColors.Neon)
            }
            games.isEmpty() -> GlowCard {
                Text(
                    "Belum ada game terdeteksi. Android hanya menandai sebagian aplikasi sebagai game, " +
                        "jadi tekan \"+ Tambah\" untuk memilih game secara manual.",
                    color = AiszColors.TextDim, fontSize = 14.sp
                )
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                itemsIndexed(games, key = { _, g -> g.packageName }) { i, g ->
                    Appear(minOf(i, 6)) {
                        GameCard(
                            g,
                            onFav = { launcher.toggleFavorite(g.packageName); reload++ },
                            onDelete = {
                                launcher.removeGame(g.packageName)
                                Toast.makeText(ctx, "${g.label} dihapus dari daftar (aplikasi tidak di-uninstall)", Toast.LENGTH_SHORT).show()
                                reload++
                            },
                            onProfile = { launcher.cycleProfile(g.packageName); reload++ },
                            onPlay = {
                                if (launcher.launch(g.packageName)) reload++
                                else Toast.makeText(ctx, "Tidak dapat membuka ${g.label}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = AiszColors.Surface,
            titleContentColor = AiszColors.Neon,
            textContentColor = AiszColors.Text,
            title = { Text("Tambah game") },
            text = {
                if (addable.isEmpty()) {
                    Text("Tidak ada aplikasi lain yang bisa ditambahkan.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(addable, key = { it.packageName }) { a ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        launcher.addGame(a.packageName)
                                        showAdd = false
                                        reload++
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val icon = a.icon
                                if (icon != null) {
                                    Image(
                                        bitmap = icon, contentDescription = null,
                                        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                }
                                Text(
                                    a.label, color = AiszColors.Text, modifier = Modifier.padding(start = 12.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAdd = false }) { Text("Tutup", color = AiszColors.Neon) } }
        )
    }
}

// =============================================================== MONITOR

@Composable
fun MonitorScreen() {
    val ctx = LocalContext.current
    val perf = remember { PerformanceMonitor(ctx) }
    val thermalMonitor = remember { TemperatureMonitor(ctx) }
    val netMonitor = remember { NetworkMonitor(ctx) }
    val device = remember { perf.deviceInfo() }
    var memory by remember { mutableStateOf(perf.memory()) }
    var battery by remember { mutableStateOf(perf.battery()) }
    var thermal by remember { mutableStateOf(thermalMonitor.read()) }
    var netText by remember { mutableStateOf("...") }
    var ping by remember { mutableStateOf<Int?>(null) }
    var ramHist by remember { mutableStateOf<List<Float>>(emptyList()) }
    var tempHist by remember { mutableStateOf<List<Float>>(emptyList()) }
    var pingHist by remember { mutableStateOf<List<Float>>(emptyList()) }

    LaunchedEffect(Unit) {
        while (true) {
            memory = perf.memory()
            battery = perf.battery()
            thermal = thermalMonitor.read()
            ramHist = (ramHist + memory.usedPercent / 100f).takeLast(40)
            thermal.batteryC?.let { tempHist = (tempHist + it).takeLast(40) }
            val (n, p) = withContext(Dispatchers.IO) {
                val st = netMonitor.status()
                val txt = buildString {
                    append(st.transport)
                    if (st.rssiDbm != null) append("  ${st.rssiDbm} dBm")
                    if (st.linkMbps != null) append("  ${st.linkMbps} Mbps")
                    if (st.band != null) append("  ${st.band}")
                }
                txt to netMonitor.pingMs()
            }
            netText = n
            ping = p
            if (p != null) pingHist = (pingHist + p.toFloat()).takeLast(40)
            delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenTitle("Monitor", "Diperbarui setiap 2 detik") }
            Box(Modifier.size(12.dp).clip(CircleShape).background(AiszColors.Ok))
            Text("  LIVE", color = AiszColors.Ok, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Appear(0) {
            GlowCard {
                SectionTitle("FPS")
                StatRow("FPS game", "Lihat di panel melayang")
                StatRow("Refresh rate layar", String.format(Locale.US, "%.0f Hz", device.refreshRateHz))
                Text(
                    "FPS game dibaca saat game terbuka dan butuh Shizuku (atur di tab Atur). " +
                        "Tanpa Shizuku, FPS game tampil N/A.",
                    color = AiszColors.TextDim, fontSize = 11.sp
                )
            }
        }

        Appear(1) {
            GlowCard {
                SectionTitle("Jaringan")
                StatRow("Koneksi", netText)
                StatRow("Latensi", ping?.let { "$it ms" } ?: "N/A")
                Sparkline(pingHist, AiszColors.Neon, Modifier.fillMaxWidth().height(60.dp), 0f, 200f)
            }
        }

        Appear(2) {
            GlowCard {
                SectionTitle("Temperatur")
                StatRow("Suhu baterai", formatCelsius(thermal.batteryC))
                StatRow("Indikator", thermal.level.label, levelColor(thermal.level))
                StatRow("Status termal sistem", thermal.thermalStatus ?: "N/A (butuh Android 10+)")
                Sparkline(tempHist, levelColor(thermal.level), Modifier.fillMaxWidth().height(60.dp), 25f, 50f)
                Text(
                    "Normal < 38 °C, Hangat 38-42 °C, Tinggi >= 42 °C (atau status termal sistem Sedang ke atas).",
                    color = AiszColors.TextDim, fontSize = 11.sp
                )
            }
        }

        Appear(3) {
            GlowCard {
                SectionTitle("RAM")
                StatRow("Total", "${memory.totalMb} MB")
                StatRow("Tersedia", "${memory.availMb} MB")
                StatRow("Terpakai", "${memory.usedPercent}%")
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { memory.usedPercent / 100f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (memory.usedPercent >= 90) AiszColors.Hot else AiszColors.Neon,
                    trackColor = AiszColors.SurfaceHigh
                )
                Sparkline(ramHist, AiszColors.NeonSoft, Modifier.fillMaxWidth().height(60.dp).padding(top = 8.dp), 0f, 1f)
            }
        }

        Appear(4) {
            GlowCard {
                SectionTitle("Baterai")
                StatRow("Level", battery.levelPercent?.let { "$it%" } ?: "N/A")
                StatRow("Status", if (battery.charging) "Mengisi" else "Tidak mengisi")
                StatRow("Tegangan", battery.voltageMv?.let { "$it mV" } ?: "N/A")
            }
        }

        Appear(5) {
            GlowCard {
                SectionTitle("Perangkat")
                StatRow("Model", "${device.manufacturer} ${device.model}")
                StatRow("Android", "${device.androidVersion} (API ${device.apiLevel})")
                StatRow("Arsitektur", device.abi)
                StatRow("Core CPU", "${device.cpuCores}")
                StatRow("Layar", device.screen)
            }
        }
    }
}

// =============================================================== SETTINGS

@Composable
fun SettingsScreen(activity: MainActivity) {
    val ctx = LocalContext.current
    val gs = remember { GameSettings(ctx) }
    val scope = rememberCoroutineScope()
    val tick = activity.resumeTick.value

    var canWrite by remember(tick) { mutableStateOf(gs.canWriteSystemSettings()) }
    var overlayOk by remember(tick) { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var dndAccess by remember(tick) { mutableStateOf(gs.hasDndAccess()) }
    var dndOn by remember(tick) { mutableStateOf(gs.isDndOn()) }
    var brightness by remember(tick) { mutableStateOf(gs.getBrightnessPercent().toFloat()) }
    var musicVol by remember { mutableStateOf(gs.getVolumePercent(AudioManager.STREAM_MUSIC).toFloat()) }
    var ringVol by remember { mutableStateOf(gs.getVolumePercent(AudioManager.STREAM_RING).toFloat()) }
    var profile by remember { mutableStateOf(gs.profile) }
    var orientation by remember { mutableStateOf(gs.orientation) }
    var keepOn by remember { mutableStateOf(gs.keepScreenOn) }
    var dock by remember { mutableStateOf(gs.dockApps) }
    var showDock by remember { mutableStateOf(false) }
    var allApps by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    var shizukuInstalled by remember { mutableStateOf(false) }
    var shizukuRunning by remember { mutableStateOf(false) }
    var shizukuGranted by remember { mutableStateOf(false) }

    LaunchedEffect(tick) {
        while (true) {
            shizukuInstalled = ShizukuHelper.isInstalled(ctx)
            shizukuRunning = ShizukuHelper.isRunning()
            shizukuGranted = withContext(Dispatchers.IO) { ShizukuHelper.hasPermission() }
            delay(2000)
        }
    }

    val sliderColors = SliderDefaults.colors(
        thumbColor = AiszColors.Neon,
        activeTrackColor = AiszColors.Neon,
        inactiveTrackColor = AiszColors.SurfaceHigh
    )
    val switchColors = SwitchDefaults.colors(
        checkedTrackColor = AiszColors.Neon, checkedThumbColor = AiszColors.Black,
        uncheckedTrackColor = AiszColors.SurfaceHigh, uncheckedThumbColor = AiszColors.TextDim
    )

    fun toggleDock(pkg: String) {
        dock = when {
            pkg in dock -> dock - pkg
            dock.size < 4 -> dock + pkg
            else -> {
                Toast.makeText(ctx, "Maksimal 4 aplikasi di dock.", Toast.LENGTH_SHORT).show()
                dock
            }
        }
        gs.dockApps = dock
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Pengaturan")

        GlowCard {
            SectionTitle("Shizuku / ADB nirkabel")
            StatRow("Aplikasi Shizuku", if (shizukuInstalled) "Terpasang" else "Belum terpasang",
                if (shizukuInstalled) AiszColors.Ok else AiszColors.Warn)
            StatRow("Layanan Shizuku", if (shizukuRunning) "Berjalan" else "Belum berjalan",
                if (shizukuRunning) AiszColors.Ok else AiszColors.Warn)
            StatRow("Izin untuk AISZ", if (shizukuGranted) "Diizinkan" else "Belum",
                if (shizukuGranted) AiszColors.Ok else AiszColors.Warn)
            Spacer(Modifier.height(6.dp))
            Text(
                "Dengan Shizuku, AISZ bisa membaca FPS game, memakai Game Mode & Penghemat Baterai, " +
                    "mengunci refresh rate, dan membuka jendela mengambang. Tanpa Shizuku, fitur itu dinonaktifkan.",
                color = AiszColors.TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            when {
                !shizukuInstalled -> GhostButton("Pasang Shizuku", Modifier.fillMaxWidth()) {
                    ctx.safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
                }
                !shizukuRunning -> GhostButton("Buka Shizuku untuk memulai", Modifier.fillMaxWidth()) {
                    val i = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
                    if (i != null) ctx.safeStart(i)
                }
                !shizukuGranted -> NeonButton("Izinkan AISZ memakai Shizuku", Modifier.fillMaxWidth()) {
                    ShizukuHelper.requestPermission()
                }
                else -> Text("Shizuku siap dipakai.", color = AiszColors.Ok, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "Cara memulai lewat ADB nirkabel (tanpa PC, Android 11+):\n" +
                    "1. Pengaturan > Tentang ponsel > ketuk versi OS 7x untuk membuka Opsi pengembang.\n" +
                    "2. Opsi pengembang > aktifkan Debugging nirkabel (sambungkan ke Wi-Fi).\n" +
                    "3. Buka Shizuku > Mulai lewat Debugging nirkabel > ikuti langkah pairing.\n" +
                    "4. Kembali ke sini dan ketuk Izinkan.\n" +
                    "Lewat PC: adb shell sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh",
                color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp)
            )
        }

        GlowCard {
            SectionTitle("Mode: hemat daya / seimbang / performa")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GamingProfile.values().forEach { p -> NeonChip(p.label, profile == p) { profile = p } }
            }
            Spacer(Modifier.height(8.dp))
            Text(profile.description, color = AiszColors.TextDim, fontSize = 12.sp)
            Text(
                "Efek Game Mode bergantung pada game dan ROM. Mode tidak menjamin kenaikan FPS.",
                color = AiszColors.TextDim, fontSize = 11.sp
            )
            Spacer(Modifier.height(10.dp))
            NeonButton("Terapkan mode", Modifier.fillMaxWidth()) {
                ModeController.applyAsync(ctx, profile, null) { msg ->
                    keepOn = gs.keepScreenOn
                    brightness = gs.getBrightnessPercent().toFloat()
                    musicVol = gs.getVolumePercent(AudioManager.STREAM_MUSIC).toFloat()
                    activity.applyWindowPrefs()
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                }
            }
        }

        GlowCard {
            SectionTitle("Jendela mengambang")
            Text(
                "Pilih sampai 4 aplikasi untuk dock di panel melayang. Ketuk ikonnya di panel untuk membuka " +
                    "dalam jendela mengambang (freeform). Butuh Shizuku dan dukungan ROM; jika tidak didukung, " +
                    "aplikasi dibuka biasa.",
                color = AiszColors.TextDim, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            StatRow("Terpilih", "${dock.size} / 4")
            GhostButton("Atur aplikasi dock", Modifier.fillMaxWidth()) {
                scope.launch {
                    allApps = withContext(Dispatchers.IO) { GameLauncher(ctx).allApps() }
                    showDock = true
                }
            }
            Spacer(Modifier.height(6.dp))
            GhostButton("Reset pengaturan jendela sistem", Modifier.fillMaxWidth()) {
                scope.launch {
                    val r = withContext(Dispatchers.IO) { ShellTools.resetFreeform() }
                    Toast.makeText(
                        ctx,
                        if (r.ok) "Pengaturan freeform dikembalikan. Mulai ulang HP bila perlu." else "Butuh Shizuku aktif.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            Text(
                "Bentuk sudut dan latar belakang jendela mengambang ditentukan HyperOS, bukan AISZ. " +
                    "Jika layar belakang jadi hitam, coba tombol reset di atas lalu mulai ulang HP.",
                color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }

        GlowCard {
            SectionTitle("Kecerahan")
            if (!canWrite) {
                Text(
                    "Mengubah kecerahan sistem memerlukan izin \"Ubah pengaturan sistem\" (atau Shizuku di panel melayang).",
                    color = AiszColors.Warn, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                GhostButton("Berikan izin") { ctx.safeStart(gs.writeSettingsIntent()) }
            } else {
                StatRow("Level", "${brightness.toInt()}%")
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    onValueChangeFinished = { gs.setBrightnessPercent(brightness.toInt()) },
                    valueRange = 1f..100f,
                    colors = sliderColors
                )
            }
        }

        GlowCard {
            SectionTitle("Volume")
            StatRow("Media", "${musicVol.toInt()}%")
            Slider(
                value = musicVol,
                onValueChange = {
                    musicVol = it
                    gs.setVolumePercent(AudioManager.STREAM_MUSIC, it.toInt())
                },
                valueRange = 0f..100f, colors = sliderColors
            )
            StatRow("Dering", "${ringVol.toInt()}%")
            Slider(
                value = ringVol,
                onValueChange = {
                    ringVol = it
                    if (!gs.setVolumePercent(AudioManager.STREAM_RING, it.toInt())) {
                        Toast.makeText(ctx, "Volume dering tidak dapat diubah (mode Jangan Ganggu aktif?).", Toast.LENGTH_SHORT).show()
                    }
                },
                valueRange = 0f..100f, colors = sliderColors
            )
        }

        GlowCard {
            SectionTitle("Jangan Ganggu")
            if (!dndAccess) {
                Text("Butuh izin akses Jangan Ganggu dari Android.", color = AiszColors.Warn, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                GhostButton("Berikan izin") { ctx.safeStart(gs.dndIntent()) }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Aktifkan saat bermain", color = AiszColors.Text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                    Switch(
                        checked = dndOn,
                        onCheckedChange = { if (gs.setDnd(it)) dndOn = it },
                        colors = switchColors
                    )
                }
            }
        }

        GlowCard {
            SectionTitle("Orientasi & layar")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OrientationMode.values().forEach { o ->
                    NeonChip(o.label, orientation == o) {
                        orientation = o
                        gs.orientation = o
                        activity.applyWindowPrefs()
                    }
                }
            }
            Text(
                "Orientasi berlaku untuk jendela AISZ GAME SPACE. Android tidak mengizinkan aplikasi memaksa orientasi game lain.",
                color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
            )
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Layar tetap menyala (di aplikasi ini)", color = AiszColors.Text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(
                    checked = keepOn,
                    onCheckedChange = {
                        keepOn = it
                        gs.keepScreenOn = it
                        activity.applyWindowPrefs()
                    },
                    colors = switchColors
                )
            }
        }

        GlowCard {
            SectionTitle("Izin")
            StatRow("Tampil di atas aplikasi lain", if (overlayOk) "Diizinkan" else "Belum", if (overlayOk) AiszColors.Ok else AiszColors.Warn)
            StatRow("Ubah pengaturan sistem", if (canWrite) "Diizinkan" else "Belum", if (canWrite) AiszColors.Ok else AiszColors.Warn)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Izin overlay", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                GhostButton("Info aplikasi", Modifier.weight(1f)) {
                    ctx.safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }
            }
            Text(
                "Di HyperOS/MIUI, jika panel tidak muncul, buka Info aplikasi > Izin lainnya dan aktifkan " +
                    "\"Tampilkan jendela pop-up saat berjalan di latar belakang\".",
                color = AiszColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }

        GlowCard {
            SectionTitle("Pintasan pengaturan sistem")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameSettings.shortcuts.forEach { (title, action) ->
                    GhostButton(title, Modifier.weight(1f)) { ctx.safeStart(Intent(action)) }
                }
            }
        }
    }

    if (showDock) {
        AlertDialog(
            onDismissRequest = { showDock = false },
            containerColor = AiszColors.Surface,
            titleContentColor = AiszColors.Neon,
            textContentColor = AiszColors.Text,
            title = { Text("Aplikasi dock (maks. 4)") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(allApps, key = { it.packageName }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { toggleDock(a.packageName) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = a.packageName in dock,
                                onCheckedChange = null,
                                colors = CheckboxDefaults.colors(checkedColor = AiszColors.Neon, checkmarkColor = AiszColors.Black)
                            )
                            val icon = a.icon
                            if (icon != null) {
                                Image(
                                    bitmap = icon, contentDescription = null,
                                    modifier = Modifier.padding(start = 8.dp).size(32.dp).clip(RoundedCornerShape(8.dp))
                                )
                            }
                            Text(
                                a.label, color = AiszColors.Text, modifier = Modifier.padding(start = 10.dp),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDock = false }) { Text("Selesai", color = AiszColors.Neon) } }
        )
    }
}
