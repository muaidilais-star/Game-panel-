package com.aisz.gamespace.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aisz.gamespace.FloatingPanelService
import com.aisz.gamespace.GameInfo
import com.aisz.gamespace.GameLauncher
import com.aisz.gamespace.MainActivity
import com.aisz.gamespace.PerformanceMonitor
import com.aisz.gamespace.ShizukuHelper
import com.aisz.gamespace.TemperatureMonitor
import com.aisz.gamespace.formatCelsius
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun TokenBar(modifier: Modifier) {
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { target = 1f }
    val f by animateFloatAsState(target, tween(900), label = "token")
    Box(modifier.height(6.dp).clip(RoundedCornerShape(3.dp)).background(AiszColors.SurfaceHigh)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(f)
                .background(Brush.horizontalGradient(listOf(AiszColors.Neon, AiszColors.NeonSoft)))
        )
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color, modifier: Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape)
            .background(AiszColors.Surface.copy(alpha = 0.9f))
            .border(1.dp, AiszColors.Neon.copy(alpha = 0.2f), shape)
            .padding(12.dp)
    ) {
        Text(label, color = AiszColors.TextDim, fontSize = 11.sp, letterSpacing = 1.sp)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PlayPill(text: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(AiszColors.NeonSoft)
            .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = AiszColors.Black, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, color = AiszColors.Black, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun LastPlayedCard(g: GameInfo, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        Modifier.fillMaxWidth().height(200.dp).clip(shape)
            .border(1.dp, AiszColors.Neon.copy(alpha = 0.3f), shape)
            .background(AiszColors.Surface).clickable(onClick = onClick)
    ) {
        val icon = g.icon
        // Latar: ikon diperbesar (tampak seperti blur) tanpa efek blur yang berat.
        if (icon != null) {
            Image(
                bitmap = icon, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, alpha = 0.55f
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(AiszColors.Black.copy(alpha = 0.88f), AiszColors.Black.copy(alpha = 0.3f)))
            )
        )
        Column(
            Modifier.fillMaxHeight().fillMaxWidth(0.62f).padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("TERAKHIR DIMAINKAN", color = AiszColors.NeonSoft, fontSize = 11.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    g.label, color = AiszColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (g.lastLaunch > 0) "${g.launches}x dibuka  •  ${relativeTime(g.lastLaunch)}" else "Belum pernah dibuka",
                    color = AiszColors.TextDim, fontSize = 13.sp
                )
            }
            PlayPill("Main", onClick)
        }
        if (icon != null) {
            val iconShape = RoundedCornerShape(26.dp)
            Image(
                bitmap = icon, contentDescription = g.label,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 22.dp).size(104.dp)
                    .rotate(8f).clip(iconShape).border(3.dp, AiszColors.NeonSoft, iconShape)
            )
        }
    }
}

@Composable
private fun GameRow(g: GameInfo, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(AiszColors.Surface.copy(alpha = 0.9f))
            .border(1.dp, AiszColors.Neon.copy(alpha = 0.15f), shape)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val icon = g.icon
        if (icon != null) {
            Image(bitmap = icon, contentDescription = g.label, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)))
        } else {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(AiszColors.SurfaceHigh))
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(
                g.label, color = AiszColors.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (g.lastLaunch > 0) "${g.launches}x dibuka  •  ${relativeTime(g.lastLaunch)}" else "Belum pernah dibuka",
                color = AiszColors.TextDim, fontSize = 13.sp
            )
        }
        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = null, tint = AiszColors.TextDim)
    }
}

@Composable
private fun Segment(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) AiszColors.NeonSoft else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = if (selected) AiszColors.Black else AiszColors.TextDim,
            fontWeight = FontWeight.Bold, fontSize = 15.sp
        )
    }
}

/** Tombol "tahan untuk main": mengisi dari kiri ke kanan; lepas sebelum penuh = batal. */
@Composable
private fun HoldToPlay(subtitle: String, onComplete: () -> Unit) {
    val ctx = LocalContext.current
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.fillMaxWidth().height(72.dp).clip(shape)
            .background(AiszColors.SurfaceHigh)
            .border(1.dp, AiszColors.Neon.copy(alpha = 0.5f), shape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        val job = scope.launch {
                            progress.animateTo(1f, tween(650, easing = LinearEasing))
                            onComplete()
                        }
                        tryAwaitRelease()
                        if (progress.value < 1f) {
                            job.cancel()
                            scope.launch { progress.snapTo(0f) }
                        }
                    },
                    onTap = { Toast.makeText(ctx, "Tahan tombol untuk bermain", Toast.LENGTH_SHORT).show() }
                )
            }
    ) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(progress.value)
                .background(AiszColors.Neon.copy(alpha = 0.35f))
        )
        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(AiszColors.Neon.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = AiszColors.Neon) }
            Column(Modifier.padding(start = 14.dp)) {
                Text("Tahan untuk Main", color = AiszColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = AiszColors.TextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
        }
    }
}

@Composable
private fun GameSheet(
    g: GameInfo,
    shizuku: Boolean,
    onDismiss: () -> Unit,
    onProfile: () -> Unit,
    onPlay: (Boolean) -> Unit
) {
    var gameSpace by remember { mutableStateOf(true) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val noRipple = remember { MutableInteractionSource() }
    val noRipple2 = remember { MutableInteractionSource() }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f))
                .clickable(interactionSource = noRipple, indication = null) { onDismiss() }
        )
        AnimatedVisibility(
            visible = shown,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(260)) { it }
        ) {
            val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(AiszColors.Surface)
                    .border(1.dp, AiszColors.Neon.copy(alpha = 0.35f), shape)
                    .clickable(interactionSource = noRipple2, indication = null) {}
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(4.dp)
                        .clip(RoundedCornerShape(2.dp)).background(AiszColors.TextDim.copy(alpha = 0.5f))
                )
                Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(22.dp))) {
                    val icon = g.icon
                    if (icon != null) {
                        Image(
                            bitmap = icon, contentDescription = g.label,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                        )
                    }
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, AiszColors.Surface))
                        )
                    )
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text("SIAP DIMAINKAN", color = AiszColors.NeonSoft, fontSize = 11.sp, letterSpacing = 3.sp)
                        Text(
                            g.label, color = AiszColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    val pill = RoundedCornerShape(50)
                    Text(
                        "${g.launches}x main", color = AiszColors.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 10.dp).clip(pill)
                            .border(1.dp, AiszColors.Neon.copy(alpha = 0.5f), pill)
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                val segShape = RoundedCornerShape(20.dp)
                Row(
                    Modifier.fillMaxWidth().clip(segShape).background(AiszColors.SurfaceHigh)
                        .border(1.dp, AiszColors.Neon.copy(alpha = 0.2f), segShape).padding(4.dp)
                ) {
                    Segment("Game Space", gameSpace, Modifier.weight(1f)) { gameSpace = true }
                    Segment("Langsung", !gameSpace, Modifier.weight(1f)) { gameSpace = false }
                }

                val cardShape = RoundedCornerShape(20.dp)
                Row(
                    Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(cardShape)
                        .background(AiszColors.SurfaceHigh.copy(alpha = 0.6f))
                        .border(1.dp, AiszColors.Neon.copy(alpha = 0.2f), cardShape)
                ) {
                    Column(Modifier.weight(1f).padding(14.dp)) {
                        Text("YANG AKTIF", color = AiszColors.TextDim, fontSize = 11.sp, letterSpacing = 3.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (gameSpace) {
                                NeonChip(g.profile?.label ?: "Tanpa profil", g.profile != null, onClick = onProfile)
                                NeonChip("Overlay", true) {}
                                NeonChip("Shizuku", shizuku) {}
                            } else {
                                NeonChip("Tanpa efek tambahan", false) {}
                            }
                        }
                    }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(AiszColors.Neon.copy(alpha = 0.15f)))
                    Column(Modifier.width(96.dp).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TOKEN", color = AiszColors.TextDim, fontSize = 11.sp, letterSpacing = 3.sp)
                        Text("∞", color = AiszColors.NeonSoft, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HoldToPlay(if (gameSpace) "VIA GAME SPACE" else "LANGSUNG") { onPlay(gameSpace) }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun HomeScreen(activity: MainActivity, onNavigate: (Tab) -> Unit) {
    val ctx = LocalContext.current
    val launcher = remember { GameLauncher(ctx) }
    val perf = remember { PerformanceMonitor(ctx) }
    val thermalMonitor = remember { TemperatureMonitor(ctx) }
    val device = remember { perf.deviceInfo() }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    var games by remember { mutableStateOf<List<GameInfo>>(emptyList()) }
    var reload by remember { mutableStateOf(0) }
    var memPct by remember { mutableStateOf(perf.memory().usedPercent) }
    var thermal by remember { mutableStateOf(thermalMonitor.read()) }
    var shizuku by remember { mutableStateOf(false) }
    var selectedPkg by remember { mutableStateOf<String?>(null) }
    var showPermDialog by remember { mutableStateOf(false) }
    val tick = activity.resumeTick.value

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(reload, tick) {
        games = withContext(Dispatchers.IO) { launcher.loadGames() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            memPct = perf.memory().usedPercent
            thermal = thermalMonitor.read()
            shizuku = withContext(Dispatchers.IO) { ShizukuHelper.hasPermission() }
            delay(4000)
        }
    }

    fun enablePanel(): Boolean {
        if (!Settings.canDrawOverlays(ctx)) {
            showPermDialog = true
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        FloatingPanelService.start(ctx)
        return true
    }

    fun play(g: GameInfo, gameSpace: Boolean) {
        if (gameSpace && !enablePanel()) return
        if (!launcher.launch(g.packageName, applyProfile = gameSpace)) {
            Toast.makeText(ctx, "Tidak dapat membuka ${g.label}", Toast.LENGTH_SHORT).show()
        }
        selectedPkg = null
        reload++
    }

    val last = games.filter { it.lastLaunch > 0 }.maxByOrNull { it.lastLaunch } ?: games.firstOrNull()
    val others = games.filter { it.packageName != last?.packageName }.take(10)
    val selected = games.firstOrNull { it.packageName == selectedPkg }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Appear(0) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Home", color = AiszColors.Text, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("PERANGKAT", color = AiszColors.TextDim, fontSize = 10.sp, letterSpacing = 3.sp)
                        Text(
                            device.model.uppercase(), color = AiszColors.Text, fontSize = 15.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .border(1.dp, AiszColors.Neon.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Person, contentDescription = null, tint = AiszColors.Neon) }
                }
            }

            Appear(1) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(120.dp)
                            .shadow(24.dp, CircleShape, ambientColor = AiszColors.Neon, spotColor = AiszColors.Neon)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(AiszColors.SurfaceHigh, AiszColors.Black)))
                            .border(
                                1.5.dp,
                                Brush.linearGradient(listOf(AiszColors.Neon.copy(alpha = 0.9f), AiszColors.Neon.copy(alpha = 0.1f))),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "A", color = AiszColors.Neon, fontSize = 62.sp, fontWeight = FontWeight.Black,
                            style = TextStyle(shadow = Shadow(AiszColors.Neon, Offset.Zero, 28f))
                        )
                    }
                    Column(Modifier.padding(start = 20.dp)) {
                        Text("GAME CONTROL", color = AiszColors.TextDim, fontSize = 12.sp, letterSpacing = 5.sp)
                        Text(
                            "AISZ", color = AiszColors.Text, fontSize = 46.sp, fontWeight = FontWeight.Black,
                            letterSpacing = 8.sp
                        )
                        Text("v$version", color = AiszColors.TextDim, fontSize = 13.sp)
                    }
                }
            }

            Appear(2) {
                GlowCard(contentPadding = 16.dp) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable {
                            if (enablePanel()) onNavigate(Tab.GAMES)
                        },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val boxShape = RoundedCornerShape(16.dp)
                        Box(
                            Modifier.size(56.dp).clip(boxShape).background(AiszColors.SurfaceHigh)
                                .border(1.dp, AiszColors.Neon.copy(alpha = 0.35f), boxShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = AiszColors.Neon, modifier = Modifier.size(30.dp))
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                            Text("Masuk ke", color = AiszColors.TextDim, fontSize = 13.sp)
                            Text("Game Space", color = AiszColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.ArrowForward, contentDescription = "Masuk", tint = AiszColors.Black)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(AiszColors.Neon.copy(alpha = 0.18f)))
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).border(1.5.dp, AiszColors.Neon, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text("∞", color = AiszColors.Neon, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("Token", color = AiszColors.TextDim, fontSize = 12.sp)
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("∞", color = AiszColors.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                Text("  Unlimited", color = AiszColors.TextDim, fontSize = 14.sp)
                            }
                        }
                        Spacer(Modifier.width(16.dp))
                        TokenBar(Modifier.weight(1f))
                    }
                }
            }

            Appear(3) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniStat("RAM", "$memPct%", if (memPct >= 90) AiszColors.Hot else AiszColors.Neon, Modifier.weight(1f))
                    MiniStat("SUHU", formatCelsius(thermal.batteryC), levelColor(thermal.level), Modifier.weight(1f))
                    MiniStat(
                        "SHIZUKU", if (shizuku) "Aktif" else "Mati",
                        if (shizuku) AiszColors.Ok else AiszColors.Warn, Modifier.weight(1f)
                    )
                }
            }

            Appear(4) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Perpustakaan Game", color = AiszColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("  ${games.size}", color = AiszColors.TextDim, fontSize = 14.sp)
                    Spacer(Modifier.weight(1f))
                    val pill = RoundedCornerShape(50)
                    Text(
                        "Tambah +", color = AiszColors.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(pill).background(AiszColors.SurfaceHigh)
                            .clickable { onNavigate(Tab.GAMES) }.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }

            Appear(5) {
                if (last != null) {
                    LastPlayedCard(last) { selectedPkg = last.packageName }
                } else {
                    GlowCard {
                        Text(
                            "Belum ada game terdeteksi. Buka tab Game lalu tekan \"+ Tambah\" untuk memilih game.",
                            color = AiszColors.TextDim, fontSize = 14.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        PlayPill("Buka perpustakaan") { onNavigate(Tab.GAMES) }
                    }
                }
            }

            if (others.isNotEmpty()) {
                Appear(6) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("LAINNYA", color = AiszColors.TextDim, fontSize = 12.sp, letterSpacing = 4.sp)
                        others.forEach { g -> GameRow(g) { selectedPkg = g.packageName } }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        if (selected != null) {
            GameSheet(
                g = selected,
                shizuku = shizuku,
                onDismiss = { selectedPkg = null },
                onProfile = { launcher.cycleProfile(selected.packageName); reload++ },
                onPlay = { gameSpace -> play(selected, gameSpace) }
            )
        }
    }

    if (showPermDialog) {
        AlertDialog(
            onDismissRequest = { showPermDialog = false },
            containerColor = AiszColors.Surface,
            titleContentColor = AiszColors.Neon,
            textContentColor = AiszColors.Text,
            title = { Text("Izin tampil di atas aplikasi lain") },
            text = {
                Text(
                    "Floating panel memerlukan izin \"Tampil di atas aplikasi lain\" (SYSTEM_ALERT_WINDOW). " +
                        "Aktifkan untuk AISZ GAME SPACE di pengaturan, lalu kembali ke aplikasi."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPermDialog = false
                    ctx.safeStart(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }) { Text("Buka Pengaturan", color = AiszColors.Neon) }
            },
            dismissButton = {
                TextButton(onClick = { showPermDialog = false }) { Text("Batal", color = AiszColors.TextDim) }
            }
        )
    }
}
